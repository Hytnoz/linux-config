require("theprimeagen")
vim.cmd("colorscheme rose-pine-moon")

